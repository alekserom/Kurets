import sys
print (sys.argv[1]+'1')
print (int(sys.argv[1])+1)
